package lect1;

class Circle extends Peri implements Figure {
	private int r;
	public Circle(int r ) {
		this.r =r;
	}
	
	public void set_r(int r) {this.r =r;}
	public int get_r() {return this.r;}
	
	@Override
	public double surface() {
		return (Math.PI)*Math.pow(this.get_r(),2);
	}
	@Override
	public double per() {
		return 2*(Math.PI)*this.get_r();
	}
	@Override
	public String toString() {
		return String.format("Circle R=%d\n",this.get_r());
	}

	
}
