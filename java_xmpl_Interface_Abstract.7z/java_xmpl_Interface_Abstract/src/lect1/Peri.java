package lect1;

public abstract class Peri {
	public void show() {
		System.out.println("regular method - abstract class"); 
	}
	public final void  Final() {
		System.out.println("Final method - abstract class"); 
	}

	public abstract double per();
}