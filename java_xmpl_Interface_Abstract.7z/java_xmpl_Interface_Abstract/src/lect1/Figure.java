package lect1;

interface Figure {
	public double surface();
}
