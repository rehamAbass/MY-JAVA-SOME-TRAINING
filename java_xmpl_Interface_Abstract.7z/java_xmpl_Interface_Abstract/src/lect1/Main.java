package lect1;

public class Main {
	
	static  Figure [] arr;
	public static void main(String[] args) {
		arr = new  Figure[2]; 
		arr[0]=new Circle(10);
		arr[1]=new rectangle(2,1);
		for(Figure f :arr) {
			System.out.print("\nObject:\t"+f);
			System.out.printf("\tSurface = %.1f",f.surface());
			System.out.printf("\tPer = %.1f",((Peri)f).per());
		}
	}
}
