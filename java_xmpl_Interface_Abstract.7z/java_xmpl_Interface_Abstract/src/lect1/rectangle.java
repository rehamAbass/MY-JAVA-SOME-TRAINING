package lect1;

public class rectangle extends Peri implements Figure{
	public double x;
	public double y;
	public rectangle(int i, int j) {
		x=i;
		y=j;
	}
	@Override
	public double surface() {
		return x*y;
	}
	@Override
	public double per() {
		return 2*(x+y);
	}
	@Override
	public String toString() {
		return String.format("Rectangle [%.1f,%.1f]\n",this.x,this.y);
	}	
	
}
